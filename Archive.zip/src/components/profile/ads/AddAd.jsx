import AddEditAdForm from "./AddEditAdForm";

export default function AddAdServer() {
  return <AddEditAdForm />;
}
