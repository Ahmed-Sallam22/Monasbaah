import React from "react";

export default function FavoritesTab() {
  return <div>FavoritesTab</div>;
}
